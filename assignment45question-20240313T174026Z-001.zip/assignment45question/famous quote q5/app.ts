let qoute: string= "A person who never made a mistake never tried anything new";
let famous_person="Albert Einstein";
let message=`${famous_person}once said, ${qoute}`;
console.log(message); 