var transportation = ['civic', 'bike', 'suzuki jisme cow ho'];
for (var i = 0; i < transportation.length; i++) {
    console.log('I would like to own a ' + transportation[i]);
}
