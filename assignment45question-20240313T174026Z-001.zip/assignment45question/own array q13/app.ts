let transportation :string [] = ['civic','bike','suzuki jisme cow ho'];
for(let i=0; i<transportation.length; i++){
    console.log('I would like to own a ' + transportation[i]);
}