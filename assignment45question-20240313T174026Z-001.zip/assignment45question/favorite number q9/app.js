var favoriteNumber = 4;
console.log("My favorite number is ".concat(favoriteNumber));
