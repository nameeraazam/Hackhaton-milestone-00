let favoriteNumber: number = 4;
console.log(`My favorite number is ${favoriteNumber}`);