let not_present : string = 'farhan';
let new_guest :string = 'Babar Azam';
for(let i=0; i<guest_list.length; i++){
    console.log('Respected Sir/Madam  + guest_list[i] + ;\nWe invited you on dinner tomorrow.\nThank You\n')
}



