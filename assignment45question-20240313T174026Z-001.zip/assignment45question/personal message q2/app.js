var personName = "ERIC";
console.log("hello ".concat(personName, " would you like to learn some python today?"));
