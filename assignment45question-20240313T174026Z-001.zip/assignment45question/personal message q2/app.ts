let personName: string= "ERIC";
console.log(`hello ${personName} would you like to learn some python today?`);