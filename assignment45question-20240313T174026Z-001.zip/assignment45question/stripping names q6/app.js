var personName = "\n\t BABAR AZAM\t\n";
console.log(personName);
var stripped = personName.trim();
console.log(stripped);
