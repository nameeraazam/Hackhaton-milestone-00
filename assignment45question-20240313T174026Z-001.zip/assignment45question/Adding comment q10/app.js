//exercise 10
//my name is NAMEERA
//Dated: 18/02/2024
//this program will run simple code just like hello world
console.log('hello world simple program');
