//exercise 10
//my name is NAMEERA
//Dated: 18/02/2024
//this program will multiplication
console.log(5 * 2);
