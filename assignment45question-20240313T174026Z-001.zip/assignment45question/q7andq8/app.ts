console.log(5+3);
console.log(11-3);
console.log(4 *2);
console.log(16 / 2);