var members = ['azam', 'saqlain', 'mehmood', 'saba', 'sana'];
for (var i = 0; i < members.length; i++) {
    console.log(members[i]);
}
