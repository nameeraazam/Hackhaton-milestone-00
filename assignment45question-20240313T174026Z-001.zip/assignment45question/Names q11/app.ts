let members: string[] =['azam','saqlain','mehmood','saba','sana'];
for(let i=0; i<members.length; i++){
    console.log(members[i]);
}