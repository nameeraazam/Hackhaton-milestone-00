let qoute: string= "A person who never made a mistake never tried anything new";
let author: string= "Albert Einstein"
console.log(`${author} once said, "${qoute}`);